const mongoose = require('mongoose');
var express = require('express');
var router = express.Router();
const DATABASE_CONNECTION = 'mongodb://mongo/miBBDD';
//var indexjs = require('./routes/index.js');
var app = express();
var UserSchema = mongoose.Schema({
    TipoUsuario: String,
    Correo: String,
    Nombre: String,
    Apellidos: String,
    username: String,
    password: String,
    Activado: Boolean
});

Usuario = exports.Usuario = mongoose.model('usuarios', UserSchema);
var userModel =mongoose.model('usuarios',UserSchema);
var db = mongoose.connection;
exports.initializeMongo = function(){
    mongoose.connect(DATABASE_CONNECTION, {useNewUrlParser: true});

    console.log('Trying to connect to ' + DATABASE_CONNECTION);

    db = mongoose.connection;
    db.on('error', console.error.bind(console, 'Connection error: We might not be as connected as I thought'));
    db.once('open', function(){
        console.log('Estamos conectados a la base de datos!');
       
    });
}


var LoginCorrecto;
var c;
var add= false;
//Funcion para el login LOGIN----------------------------------------------------
exports.login =async function(user, pws){

      await userModel.findOne({username: user, password: pws}, function(err, c) { // el wait es necesario, ya que si no se ejecuta despues.
          if(c!=null){
              if (c.Activado){
                add=c.TipoUsuario;
              }else{
                add= false;
              }
          }else{
            add= false;
          }
          
       });
       return add;
}
// Registro -----------------------------------------------------------------------
exports.register =function(user){
    addNewUser(user);
}

function addNewUser(user){
    db.collection("usuarios").insert(user);
}


//BACKEND

exports.getUsers =async function(){
   return await userModel.find();
}

exports.activarUsuario =async function(correo){
    await userModel.updateOne(
        {Correo: correo},
        {Activado: true}
    );
 }