const mongoose = require('mongoose');
var express = require('express');
var router = express.Router();
const DATABASE_CONNECTION = 'mongodb://mongo/miBBDD';
//var indexjs = require('./routes/index.js');
var app = express();
var UserSchema = mongoose.Schema({
    username: String,
    password: String,
    TipoUsuario: String
});

Usuario = exports.Usuario = mongoose.model('usuarios', UserSchema);
var userModel =mongoose.model('usuarios',UserSchema);
var db = mongoose.connection;
exports.initializeMongo = function(){
    mongoose.connect(DATABASE_CONNECTION, {useNewUrlParser: true});

    console.log('Trying to connect to ' + DATABASE_CONNECTION);

     db = mongoose.connection;
    db.on('error', console.error.bind(console, 'Connection error: We might not be as connected as I thought'));
    db.once('open', function(){
        console.log('Estamos conectados a la base de datos!');
       
    });
}


var LoginCorrecto;
var c;
var add= false;
//Funcion para el login LOGIN----------------------------------------------------
exports.login =async function(user, pws){

      await userModel.findOne({username: user, password: pws}, function(err, c) { // el wait es necesario, ya que si se ejecuta despues.
          //console.log(c+'Esto va antes');
         
          if(c!=null){
            if(c.TipoUsuario=="admin"){
                add=0 
            }else if(c.TipoUsuario=="Final"){
                add=1;
                }
          }else{
              add=false;
          }
       });
     return add;
}
// Registro -----------------------------------------------------------------------
exports.register =function(user){
    addNewUser(user);
}

function addNewUser(user){
        db.collection("usuarios").insert(user);
}
