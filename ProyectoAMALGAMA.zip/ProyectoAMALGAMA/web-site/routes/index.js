
var database = require('./../database');
var express = require('express');
//var session = require('express-session');
var router = express.Router();
var username;
var typouser;

router.get('/', function(req, res, next) {
  //Comprobar si hay sesión iniciada y que tipo de sesión
  if(req.session.user){
    if(req.session.tipouser=="Escritor"){
      username=req.session.user;
      res.render('index',{username : username, typouser: "Escritor", vista: "home"});
    }else if(req.session.tipouser=="admin"){
      username=req.session.user;
      res.render('index',{username : username, typouser: "admin", vista: "backendHome"});
    }
  }else{
    res.render('index',{username : undefined, typouser: "Lector", vista: "home"});
  }
});

//CERRAR SESIÓN
router.get('/logout', function(req, res, next) {
  req.session.destroy();
  username=null;
  res.render('index',{username : undefined, typouser: "Lector", vista: "home"});
});
//LOGIN BBDD ----------------------------------------------------------------
router.post("/login",async function(req, res, next) {
  //recogemos los datos 
  var user = req.body.id;
  var pw = req.body.pw;
 
    //los enviamos a una función del modelo BBDD
  let logged = await database.login(user, pw);
    switch(logged){

      case "admin":
        req.session.user=user;
        req.session.tipouser=logged;
        res.render(__dirname + "/../views/index.ejs", {username : user, typouser: logged, vista: "backendHome"});
        break;

      case "Lector":
        req.session.user=user;
        req.session.tipouser=logged;
        res.render(__dirname + "/../views/index.ejs", {username : user, typouser: logged, vista: "home"});
        break;

      case "Escritor":
        req.session.user=user;
        req.session.tipouser=logged;
        res.render(__dirname + "/../views/index.ejs", {username : user, typouser: logged, vista: "home"});
        break

      case false:
        res.render(__dirname + "/../views/index.ejs", {username : undefined, vista: "error"});
        break;
    }

});

// REGISTRO --------------------------------------------------------------------------
router.post("/registro", function(req, res) {
  
  var newUser=({
    "TipoUsuario" : req.body.TipoUsuario,
    Correo: req.body.mail,
    Nombre: req.body.name,
    Apellidos: req.body.surname,
    username: req.body.user,
    password: req.body.pw,
    Activado: false
  });

  database.register(newUser);
  res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Lector", vista: "home"});
  
});

//cargar vista contact ----------------------------------------------------------------
router.get("/contact", function(req, res) {
  if(req.session.user){
    username=req.session.user;
    res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "Lector", vista: "contact"});
  }else{
    res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Lector", vista: "contact"});
  }
});

//cargar vista home ----------------------------------------------------------------
router.get("/home", function(req, res) {
  if(req.session.user){
    username=req.session.user;
    res.render(__dirname + "/../views/index.ejs", {username : username, typouser: typouser, vista: "home"});
  }else{
    res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: typouser, vista: "home"});
  }
});

/*BACKEND*/
router.get("/homeB", function(req, res){
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendHome"});
});
router.get("/usuariosB", async function(req, res){
  let users = await database.getUsers();
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendUsers", users: users});
});
router.get("/artsB", function(req, res){
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendArts"});
});

router.post("/activarUser", async function(req, res){
  await database.activarUsuario(req.body.correoActivar);
  let users = await database.getUsers();
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendUsers", users: users});
});



module.exports = router;



