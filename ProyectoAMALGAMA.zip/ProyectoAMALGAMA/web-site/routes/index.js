
var database = require('./../database');
var express = require('express');
//var session = require('express-session');
var router = express.Router();
var username;
router.get('/', function(req, res, next) {
  if(req.session.email){
    username=req.session.email;
    res.render('index',{username : username});
  }else{
    res.render('index');
  }
    
});
//CERRAR SESIÓN
router.get('/logout', function(req, res, next) {
  req.session.destroy();
  username=null;
  res.render('index',{username : undefined});
});
//LOGIN BBDD ----------------------------------------------------------------
router.post("/login",async function(req, res, next) {
        //recogemos los datos 
    var user = req.body.id;
    var pw = req.body.pw;
        //los enviamos a una función del modelo BBDD
    let logged = await database.login(user, pw);
    //console.log(logged+'Este va despues');
   if(logged == true  ){
      req.session.email=user;
      res.render(__dirname + "/../views/index.ejs", {username : user});
      
    }else{
      res.send("login incorrecto");
    }
 
});
// REGISTRO --------------------------------------------------------------------------
router.post("/registro", function(req, res) {

  var newUser=({
    "Tipo Usuario" : "Final",
    Correo: req.body.mail,
    Nombre: req.body.name,
    Apellidos: req.body.surname,
    username: req.body.user,
    password: req.body.pw
  })

  database.register(newUser);
  res.render(__dirname + "/../views/index.ejs");
  
});

//cargar vista contact ----------------------------------------------------------------
router.get("/contact", function(req, res) {
  res.render(__dirname + "/../views/contact.ejs");
});

//cargar vista home ----------------------------------------------------------------
router.get("/home", function(req, res) {
  res.render(__dirname + "/../views/index.ejs");
});


module.exports = router;



