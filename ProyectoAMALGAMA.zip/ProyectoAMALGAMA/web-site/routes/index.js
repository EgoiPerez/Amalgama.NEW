
var database = require('./../database');
var express = require('express');
//var session = require('express-session');
var router = express.Router();
var username;

router.get('/', function(req, res, next) {
  //Comprobar si hay sesión iniciada y que tipo de sesión
  if(req.session.user){
    if(req.session.tipouser=="Final"){
      username=req.session.user;
      res.render('index',{username : username, typouser: "Final", vista: "home"});
    }else if(req.session.tipouser=="admin"){
      username=req.session.user;
      res.render('index',{username : username, typouser: "admin", vista: "backend"});
    }
  }else{
    res.render('index',{username : undefined, typouser: "Final", vista: "home"});
  }
});

//CERRAR SESIÓN
router.get('/logout', function(req, res, next) {
  req.session.destroy();
  username=null;
  res.render('index',{username : undefined, typouser: "Final", vista: "home"});
});
//LOGIN BBDD ----------------------------------------------------------------
router.post("/login",async function(req, res, next) {
  //recogemos los datos 
  var user = req.body.id;
  var pw = req.body.pw;
    //los enviamos a una función del modelo BBDD
  let logged = await database.login(user, pw);

  //console.log(logged+'Este va despues');
  console.log(logged);
  if(logged  == 1){// Si el usuario es Final
    req.session.user=user;
    req.session.tipouser="Final";
    res.render(__dirname + "/../views/index.ejs", {username : user, typouser: "Final", vista: "home"});

  }else if(logged == 0){//SI el usuario es ADMIN
    req.session.user=user;
    req.session.tipouser="admin";
    res.render(__dirname + "/../views/index.ejs", {username : user, typouser: "admin", vista: "backend"});
  }else{//login incorrecto
    res.send("login incorrecto");
  }

});

// REGISTRO --------------------------------------------------------------------------
router.post("/registro", function(req, res) {

  var newUser=({
    "Tipo Usuario" : "Final",
    Correo: req.body.mail,
    Nombre: req.body.name,
    Apellidos: req.body.surname,
    username: req.body.user,
    password: req.body.pw
  })

  database.register(newUser);
  res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Final", vista: "home"});
  
});

//cargar vista contact ----------------------------------------------------------------
router.get("/contact", function(req, res) {
  if(req.session.user){
    username=req.session.user;
    res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "Final", vista: "contact"});
  }else{
    res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Final", vista: "contact"});
  }
});

//cargar vista home ----------------------------------------------------------------
router.get("/home", function(req, res) {
  if(req.session.user){
    username=req.session.user;
    res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "Final", vista: "home"});
  }else{
    res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Final", vista: "home"});
  }
});


module.exports = router;



