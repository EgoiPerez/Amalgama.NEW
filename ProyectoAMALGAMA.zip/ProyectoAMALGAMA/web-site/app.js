const express = require('express');
const database = require('./database');
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
var bodyParser = require('body-parser');
const path = require('path');
var session = require('express-session');
var io = require('socket.io');
const app = express();

database.initializeMongo();

app.listen(3000);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
// Session ---------------------------
app.use(session({secret: '123456', resave: true, saveUninitialized: true}));


app.get('/miBBDD', function(req, res){
    database.Usuario.find(function (err, kittens){
        if (err) return res.error(err);
        console.log(kittens);
        res.json(kittens);
    });
});

app.use('/', indexRouter);
app.use('/users', usersRouter);

// LOGIN *******************************************************

var router = express.Router();

router.get("/", function(req, res, next) {
    res.render("login", {
    });
});

module.exports = router;
module.exports = app;